import requests
import time 
from datetime import datetime
from datetime import timedelta, timezone
from mage_ai.data_preparation.shared.secrets import get_secret_value

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@data_loader
def load_data_from_api(*args, **kwargs):
    #obtener secrets
    client_id = get_secret_value("QBO_CLIENT_ID")
    client_secret = get_secret_value("QBO_CLIENT_SECRET")
    refresh_token = get_secret_value("QBO_REFRESH_TOKEN")
    realm_id = get_secret_value("QBO_REALM_ID")
    environment = get_secret_value("QBO_ENVIRONMENT")

    #parametros de fecha
    fecha_inicio = kwargs.get('fecha_inicio', '2026-01-01T00:00:00Z')
    fecha_fin = kwargs.get('fecha_fin', '2026-01-31T23:59:59Z')

    start_dt = datetime.fromisoformat(fecha_inicio.replace("Z", "+00:00"))
    end_dt = datetime.fromisoformat(fecha_fin.replace("Z", "+00:00"))

    print(f"Extrayendo Customers: {start_dt} a {end_dt} (env={environment})")

    #obtener el access token desde el refresh token
    token_url = "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer"
    token_response = requests.post(
        token_url,
        data={
         "grant_type": "refresh_token",
            "refresh_token": refresh_token.strip(),
        },
        headers={
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        auth=(client_id, client_secret),
        timeout=30,
    )

    #manejo de errores por token
    if token_response.status_code != 200:
        print("Token status:", token_response.status_code)
        print("Token body:", token_response.text[:1000])
    token_response.raise_for_status()

    token_data = token_response.json()
    access_token = token_data["access_token"]

    windows = []
    current = start_dt

    while current < end_dt:
        next_day = min(current + timedelta(days=1), end_dt)
        windows.append((current, next_day))
        current = next_day

    #ya con el token se puede comenzar a obtener los customers
    base_url = ( 
        "https://sandbox-quickbooks.api.intuit.com" 
        if environment == 'sandbox' 
        else "https://quickbooks.api.intuit.com" 
    )

    #lista de customers
    all_customers = []
    max_results = int(kwargs.get("page_size", 10))

    print(f"Total ventanas diarias: {len(windows)}")
    print(f"Iniciando extracción con chunking diario + paginación (max {max_results} por página)...")

    #chunking por dias
    for i, (day_start, day_end) in enumerate(windows, start=1):
        window_start_utc = day_start.strftime("%Y-%m-%dT%H:%M:%SZ")
        window_end_utc = day_end.strftime("%Y-%m-%dT%H:%M:%SZ")

        print(f"\n \nVentana {i}/{len(windows)}: {window_start_utc} → {window_end_utc}")

        window_start_time = time.time()
        window_customer_count = 0
        window_page_count = 0

        start_position = 1
        page_number = 1

        #paginacion
        while True:
            query = (
                "SELECT * FROM Customer "
                f"WHERE MetaData.LastUpdatedTime >= '{window_start_utc}' "
                f"AND MetaData.LastUpdatedTime < '{window_end_utc}' "
                f"STARTPOSITION {start_position} "
                f"MAXRESULTS {max_results}"
            )

            headers = {
                "Accept": "application/json",
                "Authorization": f"Bearer {access_token}",
            }

            response = requests.get(
                f"{base_url}/v3/company/{realm_id}/query",
                headers=headers,
                params={"query": query},
                timeout=30,
            )

            if response.status_code == 429:
                print("  Rate limit alcanzado. Esperando 30s...")
                time.sleep(30)
                continue

            if response.status_code != 200:
                print("  Status:", response.status_code)
                print("  Body:", response.text[:1000])
            response.raise_for_status()

            #respuesta del api
            data = response.json()
            customers = data.get("QueryResponse", {}).get("Customer", [])

            window_page_count += 1
            window_customer_count += len(customers)

            print(f"  Página {page_number}: {len(customers)} customers (start={start_position})")

            #fin del dia
            if not customers:
                break

            all_customers.extend(customers)

            # paginacion
            if len(customers) < max_results:
                break

            start_position += max_results
            page_number += 1
            #sobrecarga
            time.sleep(0.5)

        #logs
        window_duration = time.time() - window_start_time
        print(f"✔ Ventana {i} completada:")
        print(f"   - Customers extraídas: {window_customer_count}")
        print(f"   - Páginas procesadas: {window_page_count}")
        print(f"   - Duración: {window_duration:.2f}s")

    print(f"\nTotal customers extraídas: {len(all_customers)}")


    return {
        "realm_id": realm_id,
        "window_start_utc": start_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "window_end_utc": end_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "page_size": max_results,
        "customers": all_customers
    }


@test
def test_output(output, *args) -> None:
    assert output is not None, "The output is undefined"
    assert "customers" in output, "No se devolvió customers"
    assert "window_start_utc" in output, "Falta window_start_utc"
    assert "window_end_utc" in output, "Falta window_end_utc"
