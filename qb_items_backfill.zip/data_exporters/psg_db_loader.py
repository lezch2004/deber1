from datetime import datetime, timezone
import psycopg2
from psycopg2.extras import execute_values, Json
from mage_ai.data_preparation.shared.secrets import get_secret_value

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_data(data, *args, **kwargs):
    #obtencion de datos desde el anterior bloque
    items = data.get("items", [])
    window_start_utc = data["window_start_utc"]
    window_end_utc = data["window_end_utc"]
    page_size = int(data.get("page_size", 10))
    realm_id = str(data.get("realm_id", ""))

    if not items:
        print("No hay items para cargar.")
        return {"upserted": 0}

    # secretos postgres
    host = get_secret_value("PG_HOST")
    port = int(get_secret_value("PG_PORT"))
    db = get_secret_value("PG_DB")
    user = get_secret_value("PG_USER")
    password = get_secret_value("PG_PASSWORD")

    ingested_at_utc = datetime.now(timezone.utc)

    #trazabilidad 
    request_payload = {
        "source": "qbo",
        "entity": "Item",
        "realm_id": realm_id,
        "window_start_utc": window_start_utc,
        "window_end_utc": window_end_utc,
        "page_size": page_size,
    }

    rows = []
    skipped = 0
    for inv in items:
        inv_id = inv.get("Id")
        if inv_id is None:
            skipped += 1
            continue

        rows.append((
            str(inv_id),
            Json(inv),             
            ingested_at_utc,
            window_start_utc,
            window_end_utc,
            page_size,
            Json(request_payload),
        ))

    if not rows:
        print(f"No hubo items con Id válido. Skipped={skipped}")
        return {"upserted": 0, "skipped": skipped}

    sql = """
        INSERT INTO raw.qb_items
        (id, payload, ingested_at_utc, extract_window_start_utc, extract_window_end_utc, page_size, request_payload)
        VALUES %s
        ON CONFLICT (id) DO UPDATE
        SET payload = EXCLUDED.payload,
            ingested_at_utc = EXCLUDED.ingested_at_utc,
            extract_window_start_utc = EXCLUDED.extract_window_start_utc,
            extract_window_end_utc = EXCLUDED.extract_window_end_utc,
            page_size = EXCLUDED.page_size,
            request_payload = EXCLUDED.request_payload;
    """

    #conexion con postgres
    conn = psycopg2.connect(
        host=host, port=port, dbname=db, user=user, password=password
    )
    
    #exception sql
    try:
        with conn:
            with conn.cursor() as cur:
                execute_values(cur, sql, rows, page_size=500)
        print(f"----UPSERT completado: {len(rows)} items (skipped={skipped}).----")
        return {"upserted": len(rows), "skipped": skipped}
    finally:
        conn.close()


